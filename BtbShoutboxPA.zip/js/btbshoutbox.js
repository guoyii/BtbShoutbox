function autoRefresh()
{
    ajaxLoadShouts();
    t=setTimeout("autoRefresh()",8000);
}

function ajaxLoadShouts(){        
        var lastItem = jQuery(".shoutMessageList > li:first > input").attr("value");

        jQuery.ajax({
                type: "POST",
                async: "false",
                url: location.href,
                dataType: "json",
                data: ({'function' : 'listMessages', 'lastItemId' : lastItem}),
                success: function(data) {
                    for(var i = 0; i < data.messages.length; i++){
                    
                      if(jQuery(".shoutMessageList > li:first").size() == 0)
                      {
                        jQuery(".shoutMessageList").html("<li></li>");
                      }
                      else
                      {
                        jQuery(".shoutMessageList > li:first").before("<li></li>");
                      }
                      
                      jQuery(".shoutMessageList > li:first").hide().html(data.messages[i].html).slideDown();
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                },
                beforeSend: function(xhr) {
                xhr.setRequestHeader("X-OFFICIAL-REQUEST", "TRUE");
                },
                complete: function(XMLHttpRequest, textStatus) {
                }
                });
}


function ajaxOlderShouts(){
    
    var lastItem = jQuery(".shoutMessageList > li:last input").attr("value");
    
    jQuery.ajax({
        type: "POST",
        async: "false",
        url: location.href,
        dataType: "json",
        data: ({'function' : 'listOldMessages', 'lastItemId' : lastItem}),
        success: function(data) {
            for(var i = 0; i < data.messages.length; i++){
            
              if(jQuery(".shoutMessageList > li:first").size() == 0)
              {
                jQuery(".shoutMessageList").html("<li></li>");
              }
              else
              {
                jQuery(".shoutMessageList > li:last").after("<li></li>");
              }
              
              jQuery(".shoutMessageList > li:last").hide().html(data.messages[i].html).slideDown();
            }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
        },
        beforeSend: function(xhr) {
        xhr.setRequestHeader("X-OFFICIAL-REQUEST", "TRUE");
        },
        complete: function(XMLHttpRequest, textStatus) {
        }
    });
}


jQuery(document).ready(function () {

    var t;

    jQuery(".shoutPostButton").click(function () {
        var username = jQuery(".txtUsername").attr("value");
        var message = jQuery(".txtMessage").attr("value");

        jQuery.ajax({
            type: "POST",
            async: "false",
            url: location.href,
            dataType: "json",
            data: ({ 'function': 'shoutMessage', 'username': username, 'message': message }),
            success: function (data) {
                if (data.success) {
                    ajaxLoadShouts();
                    jQuery(".txtMessage").attr("value", "");
                } else {
                    jQuery("#profanityAlert").modal();
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
            },
            beforeSend: function (xhr) {
                xhr.setRequestHeader("X-OFFICIAL-REQUEST", "TRUE");
            },
            complete: function (XMLHttpRequest, textStatus) {
            }
        });
    });

    jQuery(".shoutDisplayOlder>a").click(function () {
        ajaxOlderShouts();
        return false;
    });

    jQuery("#refreshLink").click(function () {
        ajaxLoadShouts();
        return false;
    });

    jQuery(".deleteShout").live("click", function () {
        var itemId = jQuery(this).parent().prev().attr("value");
        var item = jQuery(this).parents("li");

        jQuery.ajax({
            type: "POST",
            async: "false",
            url: location.href,
            dataType: "json",
            data: ({ 'function': 'deleteMessage', 'itemId': itemId }),
            success: function (data) {
                if (data.success) {
                    jQuery(item).hide('fast', function(){
                                        
                    jQuery(item).remove();
                                        
                    if(data.html){
                        jQuery(".shoutMessageList > li:last").after("<li></li>");
                        jQuery(".shoutMessageList > li:last").html(data.html);
                    }                   
                    });  
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
            },
            beforeSend: function (xhr) {
                xhr.setRequestHeader("X-OFFICIAL-REQUEST", "TRUE");
            },
            complete: function (XMLHttpRequest, textStatus) {
            }
        });

        return false;
    });

});
